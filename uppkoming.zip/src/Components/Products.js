import React, { Component } from 'react';
import ProductItem from './ProductItem';

class Products extends Component {
  render() {
    if(!this.props.products) <h1>Loading...</h1>
    // förum í gegnum fylkið products sem er með hlutum af products og assignum ProductItem fyrir hvert og eitt.
    let productItems;
    if(this.props.products){
      productItems = this.props.products.map(product => {
        return (
          <ProductItem key={product.name} product={product} className="ProductGrid" />
        );
      });
    }
    return (
      <div className="row">
        {productItems}
      </div>
    );
  }
}

export default Products;
