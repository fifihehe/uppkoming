import React, { Component } from 'react';

class Checkbox extends Component {

  constructor() {
    super();
    this.state = {
      itemChecked: false
    };
  }

  updateProducts(){
    if(this.itemChecked){
      console.log("this.itemChecked");

    }

  }



  render() {
    return (
      <div className="checkbox">
       <div className="col-xs-4 col-sm-4 col-md-4 col-lg-4"></div>
        <div className="btn-group col-sm-4" data-toggle="buttons" id="button">
            <label className="checkbox">
              <input type="checkbox" value="1" defaultChecked="true" onChange={this.props.updateProducts.bind(this)}/>
              Movies
            </label>
            <label className="checkbox">
              <input type="checkbox" value="1"/>
              Shoes
            </label>
        </div>
      </div>
    );
  }
}

export default Checkbox;
