import React, {Component} from 'react';

class ProductItem extends Component {

  componentWillMount(){
    const content = this.props.product.titleLength;

    console.log(content)
  }
  render() {
    // Code below for cutting out names of films that are too long
    // const content = this.props.product.titleLength;
    // if(content>15){
    //   const prufa = this.props.product.name;
    //   prufa = prufa.substring(0,22)+"...";
    //
    //   return (
    //     <div className="col-lg-4 col-sm-5 col-xs-12 col-xl-4">
    //       <div className="innerProduct" id="productBorder">
    //         <img src={this.props.product.url} alt="prufa" width="300" height="300" className="img-circle img-centre"/>
    //         <div>
    //           <div>
    //             <h2>{prufa}</h2>
    //           </div>
    //           <div>
    //             <h3>{this.props.product.releaseDate}</h3>
    //           </div>
    //           <button className="button btn btn-primary center-block" onClick="">BUY</button>
    //         </div>
    //       </div>
    //     </div>
    //   );
    // }

    return (
      <div className="col-lg-4 col-sm-5 col-xs-12 col-xl-4">
        <div className="innerProduct" id="productBorder">
          <img src={this.props.product.url} alt="prufa" width="300" height="300" className="img-circle img-centre"/>
          <div>
            <row>
              <div className="truncate">
                <h2>{this.props.product.name}</h2>


              </div>
            </row>
            <h3>{this.props.product.releaseDate}</h3>
            <button className="button btn btn-primary center-block" onClick="">BUY</button>
          </div>
        </div>
      </div>
    );
  }
}

export default ProductItem;
