var request = require('request');
cheerio = require('cheerio');
fs = require('fs');
texts = [];
textsOfText = [];
urls = [];
names = [];
console.log("halo");

// function scrapeJordan() {
  console.log("halo");

  request('http://www.nicekicks.com/air-jordan-release-dates/', function(error, response, body) {

    if (!error && response.statusCode == 200) {
      // console.log("bodybabe") // Show the HTML for the Google homepage.
      var $ = cheerio.load(body);

      // function myhoe(image, name, releaseDate) {
      //   this.image = image;
      //   this.name = name;
      //   this.releaseDate = releaseDate;
      // }

      var pContent = $('.content p');
      var realText = pContent.text();
      var shoeName2 = $('.content h2 a');
      var realShoeName = shoeName2.text();
      names.push(realShoeName);
      // console.log(realShoeName);

      // var regexTest = /Release Date:\s(January|February|March|April|May|June|July|August|September|October|November|December)\s[0-9][0-9]?,\s201[789]/g;
      var nameRegex = /\”[A-Z]|[a-z][A-Z]|\)[A-Z]/g;
      var regexTest = /(January|February|March|April|May|June|July|August|September|October|November|December)\s[0-9][0-9]?,\s201[789]/g;

      $('img', '.content').each(function() {
        var url = $(this).attr('src');
        urls.push(url);
      });
      // Þurfum að fara í gegnum strenginn og finna nöfnin þar. Búum til reglulega segð sem skynjar þegar orðin eru klesst saman,
      // finnur indexið á skiptingunni og notar substring fallið til að skipta strengnum upp.
      var o = 0;
      var shoeArray;
      var nameArray = [];
      var indexForName;
      for (a = 0;
        (shoeArray = nameRegex.exec(realShoeName)) !== null; a++) {
        indexForName = shoeArray.index;
        var nameFromText = realShoeName.substring(o, indexForName + 1);
        o = indexForName + 1;
        nameArray.push(nameFromText);
      }

      var prufa = realShoeName.substring(0, 25);
      // console.log(prufa);

      var myArray;
      // console.log(realText);

      for (i = 0; (myArray = regexTest.exec(realText)) !== null; i++) {
        var myShoe = new Object();
        myShoe.releaseDate = myArray[0];
        myShoe.image = urls[i];
        myShoe.name = nameArray[i];
        textsOfText.push(myShoe);
        // console.log(textsOfText);
      }
      // console.log(myArray);
    }

    var jsonString = JSON.stringify({
      shoes: textsOfText
    });

    console.log(jsonString);
    // fs.writeFile("data1.json", jsonString, function(err) {
    //   if (err) {
    //     return console.log(err);
    //   }
    // });
    return jsonString;

  });

// }

// module.exports = {json: jsonString}
