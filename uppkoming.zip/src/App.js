import React, {Component} from 'react';
import Products from './Components/Products';
// import Scraper from './Components/Scraper';
import axios from 'axios';
import {Navbar, Jumbotron, Button} from 'react-bootstrap';
import Header from './Components/Header';
import Checkbox from './Components/Checkbox';
// import Skrapari from 'C:/Users/Notandi/Desktop/Tölvunarfræði/6. önn/Lokaverkefni/JordanScrape'

// import './App.css';

class App extends Component {

  constructor(props)
  {
    super(props);

    this.state = {
      products: [],
      shoeProducts: [],
      itemChecked: true
    }
  }

// If checkbox is checked, then change state and update itemChecked.
// If not, then fetch the data and put it in the array
  updateProducts() {
    if (this.state.itemChecked) {
      console.log(this.state.products);
      this.setState({products: [], itemChecked: false});
      console.log(this.state.products);
      console.log(this.state.itemChecked);
    } else {
      fetch('https://api.themoviedb.org/3/movie/upcoming?api_key=127310ed7246ca96c1987d8e8c169233&language=en-US&page=1').then((response) => {
        if (response.status !== 200) {
          console.log('Hér hefur orðið vandamál. Status Code: ' + response.status);
          return;
        }

        // Skoðum textann í svarinu
        response.json().then((data) => {
          var movieArray = [];
          for (var i = 0; i < 20; i++) {
            var movieObject = {};
            movieObject.releaseDate = data.results[i].release_date;
            movieObject.name = data.results[i].title;
            movieObject.url = "https://image.tmdb.org/t/p/w500/" + data.results[i].poster_path;
            movieArray.push(movieObject);
            movieObject.titleLength = data.results[i].title.length;
          }
          this.setState({products: movieArray, itemChecked: true})
        });
      })
    }
  }

  componentDidMount() {

    fetch('https://api.themoviedb.org/3/movie/upcoming?api_key=127310ed7246ca96c1987d8e8c169233&language=en-US&page=1').then((response) => {
      if (response.status !== 200) {
        console.log('Hér hefur orðið vandamál. Status Code: ' + response.status);
        return;
      }

      // Skoðum textann í svarinu
      response.json().then((data) => {
        var movieArray = [];
        for (var i = 0; i < 20; i++) {
          var movieObject = {};
          movieObject.releaseDate = data.results[i].release_date;
          movieObject.name = data.results[i].title;
          movieObject.url = "https://image.tmdb.org/t/p/w500/" + data.results[i].poster_path;
          movieArray.push(movieObject);
          movieObject.titleLength = data.results[i].title.length;
        }
        this.setState({products: movieArray})
      });
    })
  }

  render() {
    return (
      <div className="App">
        <div>
          <Header/>
        </div>
        <div>
          <Checkbox updateProducts={this.updateProducts.bind(this)}/>
        </div>
        <div className="content">
          <Products products={this.state.products}/>
        </div>

      </div>
    );
  }
}

export default App;
